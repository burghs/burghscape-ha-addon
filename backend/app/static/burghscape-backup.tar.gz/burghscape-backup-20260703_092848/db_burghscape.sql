--
-- PostgreSQL database dump
--

\restrict 0AuCstyeG36JiPxngb6h5D3PWJ8fuekymlmR6mmbNXYdRBbgzSFG8OaeAnEPWBl

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.support_tickets DROP CONSTRAINT IF EXISTS support_tickets_client_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subscription_tokens DROP CONSTRAINT IF EXISTS subscription_tokens_client_id_fkey;
ALTER TABLE IF EXISTS ONLY public.metric_snapshots DROP CONSTRAINT IF EXISTS metric_snapshots_instance_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ha_instances DROP CONSTRAINT IF EXISTS ha_instances_client_id_fkey;
ALTER TABLE IF EXISTS ONLY public.client_users DROP CONSTRAINT IF EXISTS client_users_client_id_fkey;
ALTER TABLE IF EXISTS ONLY public.backups DROP CONSTRAINT IF EXISTS backups_client_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alerts DROP CONSTRAINT IF EXISTS alerts_instance_id_fkey;
DROP INDEX IF EXISTS public.ix_support_tickets_id;
DROP INDEX IF EXISTS public.ix_subscription_tokens_token;
DROP INDEX IF EXISTS public.ix_subscription_tokens_id;
DROP INDEX IF EXISTS public.ix_metric_snapshots_id;
DROP INDEX IF EXISTS public.ix_ha_instances_id;
DROP INDEX IF EXISTS public.ix_clients_subdomain;
DROP INDEX IF EXISTS public.ix_clients_id;
DROP INDEX IF EXISTS public.ix_clients_email;
DROP INDEX IF EXISTS public.ix_backups_id;
DROP INDEX IF EXISTS public.ix_alerts_id;
DROP INDEX IF EXISTS public.idx_client_users_email;
DROP INDEX IF EXISTS public.idx_client_users_client_id;
ALTER TABLE IF EXISTS ONLY public.support_tickets DROP CONSTRAINT IF EXISTS support_tickets_pkey;
ALTER TABLE IF EXISTS ONLY public.subscription_tokens DROP CONSTRAINT IF EXISTS subscription_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.metric_snapshots DROP CONSTRAINT IF EXISTS metric_snapshots_pkey;
ALTER TABLE IF EXISTS ONLY public.ha_instances DROP CONSTRAINT IF EXISTS ha_instances_pkey;
ALTER TABLE IF EXISTS ONLY public.clients DROP CONSTRAINT IF EXISTS clients_pkey;
ALTER TABLE IF EXISTS ONLY public.client_users DROP CONSTRAINT IF EXISTS client_users_pkey;
ALTER TABLE IF EXISTS ONLY public.client_users DROP CONSTRAINT IF EXISTS client_users_email_key;
ALTER TABLE IF EXISTS ONLY public.backups DROP CONSTRAINT IF EXISTS backups_pkey;
ALTER TABLE IF EXISTS ONLY public.alerts DROP CONSTRAINT IF EXISTS alerts_pkey;
ALTER TABLE IF EXISTS public.support_tickets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.subscription_tokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.metric_snapshots ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ha_instances ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.clients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.client_users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.backups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.alerts ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.support_tickets_id_seq;
DROP TABLE IF EXISTS public.support_tickets;
DROP SEQUENCE IF EXISTS public.subscription_tokens_id_seq;
DROP TABLE IF EXISTS public.subscription_tokens;
DROP SEQUENCE IF EXISTS public.metric_snapshots_id_seq;
DROP TABLE IF EXISTS public.metric_snapshots;
DROP SEQUENCE IF EXISTS public.ha_instances_id_seq;
DROP TABLE IF EXISTS public.ha_instances;
DROP SEQUENCE IF EXISTS public.clients_id_seq;
DROP TABLE IF EXISTS public.clients;
DROP SEQUENCE IF EXISTS public.client_users_id_seq;
DROP TABLE IF EXISTS public.client_users;
DROP SEQUENCE IF EXISTS public.backups_id_seq;
DROP TABLE IF EXISTS public.backups;
DROP SEQUENCE IF EXISTS public.alerts_id_seq;
DROP TABLE IF EXISTS public.alerts;
DROP TYPE IF EXISTS public.subscriptiontier;
DROP TYPE IF EXISTS public.clientstatus;
DROP TYPE IF EXISTS public.backupstoragebackend;
DROP EXTENSION IF EXISTS "uuid-ossp";
--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: backupstoragebackend; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.backupstoragebackend AS ENUM (
    'R2',
    'S3',
    'LOCAL'
);


--
-- Name: clientstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.clientstatus AS ENUM (
    'ACTIVE',
    'SUSPENDED',
    'PENDING',
    'CANCELLED'
);


--
-- Name: subscriptiontier; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.subscriptiontier AS ENUM (
    'BASIC',
    'STANDARD',
    'PREMIUM'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alerts (
    id integer NOT NULL,
    instance_id integer NOT NULL,
    alert_type character varying(50) NOT NULL,
    severity character varying(20),
    message text,
    is_resolved boolean,
    created_at timestamp without time zone,
    resolved_at timestamp without time zone
);


--
-- Name: alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.alerts_id_seq OWNED BY public.alerts.id;


--
-- Name: backups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backups (
    id integer NOT NULL,
    client_id integer NOT NULL,
    filename character varying(500),
    size_bytes integer,
    onedrive_item_id character varying(255),
    status character varying(50),
    error_message text,
    started_at timestamp without time zone,
    completed_at timestamp without time zone
);


--
-- Name: backups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.backups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: backups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.backups_id_seq OWNED BY public.backups.id;


--
-- Name: client_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_users (
    id integer NOT NULL,
    client_id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'viewer'::character varying,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    last_login timestamp without time zone,
    force_password_change boolean DEFAULT true
);


--
-- Name: client_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.client_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: client_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.client_users_id_seq OWNED BY public.client_users.id;


--
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(50),
    subdomain character varying(100) NOT NULL,
    tier public.subscriptiontier NOT NULL,
    status public.clientstatus NOT NULL,
    monthly_hours_included integer,
    hours_used_this_month double precision,
    cloudflare_tunnel_id character varying(255),
    cloudflare_tunnel_token character varying(500),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    last_seen timestamp without time zone,
    tailscale_authkey character varying(500),
    backup_storage_backend character varying(50) DEFAULT 'R2'::character varying,
    backup_storage_config text
);


--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.clients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.clients_id_seq OWNED BY public.clients.id;


--
-- Name: ha_instances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ha_instances (
    id integer NOT NULL,
    client_id integer NOT NULL,
    name character varying(255),
    ha_version character varying(50),
    ip_address character varying(45),
    hostname character varying(255),
    is_online boolean,
    last_backup timestamp without time zone,
    next_backup timestamp without time zone,
    disk_usage_percent double precision,
    disk_total_gb double precision,
    disk_used_gb double precision,
    addons json,
    integrations json,
    automations_count integer,
    entities_count integer,
    updates_available json,
    created_at timestamp without time zone,
    last_seen timestamp without time zone,
    uptime_seconds integer DEFAULT 0,
    cpu_usage_percent double precision DEFAULT 0,
    memory_usage_percent double precision DEFAULT 0,
    memory_total_gb double precision DEFAULT 0,
    memory_used_gb double precision DEFAULT 0
);


--
-- Name: ha_instances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ha_instances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ha_instances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ha_instances_id_seq OWNED BY public.ha_instances.id;


--
-- Name: metric_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.metric_snapshots (
    id integer NOT NULL,
    instance_id integer,
    cpu_percent double precision,
    memory_percent double precision,
    disk_percent double precision,
    uptime_seconds integer,
    captured_at timestamp without time zone
);


--
-- Name: metric_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.metric_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: metric_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.metric_snapshots_id_seq OWNED BY public.metric_snapshots.id;


--
-- Name: subscription_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_tokens (
    id integer NOT NULL,
    client_id integer NOT NULL,
    token character varying(64) NOT NULL,
    is_active boolean,
    created_at timestamp without time zone,
    expires_at timestamp without time zone,
    last_used timestamp without time zone
);


--
-- Name: subscription_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscription_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscription_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscription_tokens_id_seq OWNED BY public.subscription_tokens.id;


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_tickets (
    id integer NOT NULL,
    client_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    hours_used double precision,
    status character varying(50),
    priority character varying(20),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    completed_at timestamp without time zone
);


--
-- Name: support_tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.support_tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: support_tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.support_tickets_id_seq OWNED BY public.support_tickets.id;


--
-- Name: alerts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts ALTER COLUMN id SET DEFAULT nextval('public.alerts_id_seq'::regclass);


--
-- Name: backups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backups ALTER COLUMN id SET DEFAULT nextval('public.backups_id_seq'::regclass);


--
-- Name: client_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_users ALTER COLUMN id SET DEFAULT nextval('public.client_users_id_seq'::regclass);


--
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_id_seq'::regclass);


--
-- Name: ha_instances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ha_instances ALTER COLUMN id SET DEFAULT nextval('public.ha_instances_id_seq'::regclass);


--
-- Name: metric_snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metric_snapshots ALTER COLUMN id SET DEFAULT nextval('public.metric_snapshots_id_seq'::regclass);


--
-- Name: subscription_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_tokens ALTER COLUMN id SET DEFAULT nextval('public.subscription_tokens_id_seq'::regclass);


--
-- Name: support_tickets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets ALTER COLUMN id SET DEFAULT nextval('public.support_tickets_id_seq'::regclass);


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alerts (id, instance_id, alert_type, severity, message, is_resolved, created_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: backups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backups (id, client_id, filename, size_bytes, onedrive_item_id, status, error_message, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: client_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_users (id, client_id, name, email, password_hash, role, is_active, created_at, last_login, force_password_change) FROM stdin;
2	8	Kenny	kenmyb@gmail.com	c0ef435d0c77bed0ad4ab3df133541f4:b45eb18bf86b77276e9be32761a6d70e0226b7a8e00d87a103311c7fea634ee5	viewer	t	2026-06-28 11:55:52.083129	2026-07-03 10:51:52.489119	f
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clients (id, name, email, phone, subdomain, tier, status, monthly_hours_included, hours_used_this_month, cloudflare_tunnel_id, cloudflare_tunnel_token, created_at, updated_at, last_seen, tailscale_authkey, backup_storage_backend, backup_storage_config) FROM stdin;
8	HA Demo	kenmyb@gmail.com		ha-demo-env	STANDARD	ACTIVE	2	1	106c9d67-14e2-4a18-9714-a9a6c56afa44	eyJhIjoiNjA2ZmVhMTY2MGQ2YjJjOTk3ZWZjZjZhMjZmNWQ3OWQiLCJ0IjoiMTA2YzlkNjctMTRlMi00YTE4LTk3MTQtYTlhNmM1NmFmYTQ0IiwicyI6ImQzUnBTNk5ENFlTcU16Z29DMFl3UWJSSU5UVExGbDVpOFU4eW9uQ1BGa0FLNS8ySnh5SG5wMVlFdnBRTG1aeDFTaXc4eUVXQzhkUGJVWGRBUzYya1VnPT0ifQ==	2026-06-26 17:37:36.8419	2026-06-28 19:23:01.275998	\N	\N	R2	\N
\.


--
-- Data for Name: ha_instances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ha_instances (id, client_id, name, ha_version, ip_address, hostname, is_online, last_backup, next_backup, disk_usage_percent, disk_total_gb, disk_used_gb, addons, integrations, automations_count, entities_count, updates_available, created_at, last_seen, uptime_seconds, cpu_usage_percent, memory_usage_percent, memory_total_gb, memory_used_gb) FROM stdin;
2	8	HA Demo's HA	2026.6.4	0.0.0.0	\N	t	\N	\N	24.2	30.79	7.45	[{"name": "Advanced Ssh Web Terminal", "slug": "advanced_ssh_web_terminal", "version": "24.0.1", "update_available": false, "state": "unknown"}, {"name": "Burghscape Agent", "slug": "burghscape_agent", "version": "0.2.22", "update_available": false, "state": "unknown"}, {"name": "Burghscape Agent", "slug": "burghscape_agent", "version": "", "update_available": false, "state": "started"}]	["brands", "motion", "camera", "met", "google_translate", "energy", "history", "geo_location", "diagnostics", "api", "mobile_app.sensor", "timer", "met.weather", "cast.media_player", "cast", "hassio.update", "date", "tts", "image_processing", "humidity", "trace", "siren", "sun.binary_sensor", "stt", "ai_task", "moisture", "alarm_control_panel", "ffmpeg", "mobile_app.binary_sensor", "update", "mobile_app.notify", "websocket_api", "mobile_app", "input_number", "wake_word", "assist_pipeline", "notify", "counter", "http", "zeroconf", "image", "shopping_list.todo", "sensor", "select", "lovelace", "infrared", "tag", "media_source", "application_credentials", "cloud.tts", "remote", "usb", "cover", "radio_frequency", "recorder", "lock", "config", "frontend", "mobile_app.device_tracker", "climate", "media_player", "ssdp", "stream", "event", "logger", "bluetooth", "energy.sensor", "input_datetime", "zone", "scene", "web_rtc", "button", "backup", "vacuum", "automation", "file_upload", "onboarding", "webhook", "homeassistant.scene", "person", "occupancy", "schedule", "unifi_discovery", "repairs", "backup.event", "switch", "file", "temperature", "search", "hassio.switch", "water_heater", "default_config", "binary_sensor", "shopping_list", "door", "light", "input_button", "time", "text", "window", "radio_browser", "todo", "blueprint", "system_log", "sun.sensor", "hassio.binary_sensor", "weather", "air_quality", "conversation", "script", "analytics", "valve", "cloud", "network", "hassio", "number", "device_automation", "auth", "google_translate.tts", "go2rtc", "logbook", "gate", "dhcp", "usage_prediction", "labs", "backup.sensor", "fan", "input_text", "device_tracker", "image_upload", "garage_door", "input_boolean", "homeassistant_alerts", "sun", "hardware", "my", "humidifier", "homeassistant", "datetime", "lawn_mower", "system_health", "input_select", "illuminance", "hassio.sensor", "intent", "persistent_notification", "assist_satellite", "battery", "power"]	0	49	["Home Assistant Core Update", "Home Assistant Operating System Update"]	2026-06-27 08:14:12.666911	2026-07-03 11:28:17.437225	0	0.6	34.7	1.92	0.67
\.


--
-- Data for Name: metric_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.metric_snapshots (id, instance_id, cpu_percent, memory_percent, disk_percent, uptime_seconds, captured_at) FROM stdin;
\.


--
-- Data for Name: subscription_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_tokens (id, client_id, token, is_active, created_at, expires_at, last_used) FROM stdin;
5	8	6d78388d612fb66b277bda272d662db8e13f15d40c8e6b8b7d1230ae896cf26d	t	2026-06-26 17:37:36.844966	2027-06-26 17:37:36.843982	2026-07-03 11:28:17.436035
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_tickets (id, client_id, title, description, hours_used, status, priority, created_at, updated_at, completed_at) FROM stdin;
12	8	HA Weekly Maintenance	Weekly Home Assistant maintenance:\n- Review HA release notes for updates\n- Check all custom components are updated\n- Verify Lovelace dashboards are functional\n- Test critical automations end-to-end\n- Check recorder/database performance\n- Review custom integration configurations\n- Validate backup integrity	1	closed	normal	2026-06-28 11:19:38.98113	2026-06-28 11:20:07.239278	2026-06-28 13:20:07.237564
\.


--
-- Name: alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.alerts_id_seq', 1, false);


--
-- Name: backups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.backups_id_seq', 1, false);


--
-- Name: client_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.client_users_id_seq', 5, true);


--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clients_id_seq', 12, true);


--
-- Name: ha_instances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ha_instances_id_seq', 2, true);


--
-- Name: metric_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.metric_snapshots_id_seq', 1, false);


--
-- Name: subscription_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscription_tokens_id_seq', 7, true);


--
-- Name: support_tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.support_tickets_id_seq', 12, true);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: client_users client_users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_users
    ADD CONSTRAINT client_users_email_key UNIQUE (email);


--
-- Name: client_users client_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_users
    ADD CONSTRAINT client_users_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: ha_instances ha_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ha_instances
    ADD CONSTRAINT ha_instances_pkey PRIMARY KEY (id);


--
-- Name: metric_snapshots metric_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metric_snapshots
    ADD CONSTRAINT metric_snapshots_pkey PRIMARY KEY (id);


--
-- Name: subscription_tokens subscription_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_tokens
    ADD CONSTRAINT subscription_tokens_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: idx_client_users_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_users_client_id ON public.client_users USING btree (client_id);


--
-- Name: idx_client_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_client_users_email ON public.client_users USING btree (email);


--
-- Name: ix_alerts_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_alerts_id ON public.alerts USING btree (id);


--
-- Name: ix_backups_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_backups_id ON public.backups USING btree (id);


--
-- Name: ix_clients_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_clients_email ON public.clients USING btree (email);


--
-- Name: ix_clients_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_clients_id ON public.clients USING btree (id);


--
-- Name: ix_clients_subdomain; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_clients_subdomain ON public.clients USING btree (subdomain);


--
-- Name: ix_ha_instances_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ha_instances_id ON public.ha_instances USING btree (id);


--
-- Name: ix_metric_snapshots_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_metric_snapshots_id ON public.metric_snapshots USING btree (id);


--
-- Name: ix_subscription_tokens_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_subscription_tokens_id ON public.subscription_tokens USING btree (id);


--
-- Name: ix_subscription_tokens_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_subscription_tokens_token ON public.subscription_tokens USING btree (token);


--
-- Name: ix_support_tickets_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_tickets_id ON public.support_tickets USING btree (id);


--
-- Name: alerts alerts_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES public.ha_instances(id);


--
-- Name: backups backups_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: client_users client_users_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_users
    ADD CONSTRAINT client_users_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: ha_instances ha_instances_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ha_instances
    ADD CONSTRAINT ha_instances_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: metric_snapshots metric_snapshots_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metric_snapshots
    ADD CONSTRAINT metric_snapshots_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES public.ha_instances(id);


--
-- Name: subscription_tokens subscription_tokens_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_tokens
    ADD CONSTRAINT subscription_tokens_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: support_tickets support_tickets_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 0AuCstyeG36JiPxngb6h5D3PWJ8fuekymlmR6mmbNXYdRBbgzSFG8OaeAnEPWBl

